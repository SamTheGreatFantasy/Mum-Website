import React, { useEffect, useRef, useState } from "react";
import aboutYarnAndNeedles from "./assets/about/aboutYarnAndNeedles.jpg";
import aboutDuck from "./assets/about/aboutDuckImage.webp";
import aboutChristian from "./assets/about/aboutChristian.webp";
import clickMp3 from "./assets/Sounds/click.mp3";
import "./App.css";

const createPlaceholderImage = (label, accent) => {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600">
      <rect width="800" height="600" rx="36" fill="#fff8f2" />
      <circle cx="220" cy="240" r="120" fill="${accent}" opacity="0.22" />
      <circle cx="560" cy="190" r="90" fill="#f2c7b0" opacity="0.25" />
      <rect x="180" y="370" width="440" height="110" rx="24" fill="#ffffff" stroke="${accent}" stroke-width="8" stroke-opacity="0.38" />
      <text x="400" y="420" text-anchor="middle" font-family="Segoe UI, sans-serif" font-size="34" fill="#8f624f">${label}</text>
    </svg>
  `;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
};

const tabContent = {
  pattern: {
    title: "Pattern Dashboard",
    body: "Browse and manage your knitting patterns here.",
  },
  favourites: {
    title: "Favourites",
    body: "Your saved patterns and inspiration live here.",
  },
  account: {
    title: "My Account",
    body: "Update your profile, settings, and preferences.",
  },
  shop: {
    title: "Shop",
    body: "Explore beautiful knitting supplies, patterns, and useful tools for every stitch.",
  },
  contact: {
    title: "Contact Us",
    body: "Need help or want to say hi? We are always happy to hear from fellow knitters.",
  },
  about: {
    title: "The Creation of Fitting in Knitting",
    body: `Hello!

I'm Ali, also known as Ali Corah, and I'm pleased you've popped by here to see more about the creation of Fitting in Knitting, which has come about over years of lovely knitting, combined with hard work and stressing and nail biting...

My boss retired at the end of December 2017, and prior to this she had given me fantastic support and encouragement over a few years with my day job. This prompted me to make something extra special to express my gratitude. I thought these two little ducks would be perfect, made from a pattern given to me by my late grandma. It was this that reignited my love of knitting. I wanted to get back into something I really enjoy but have lost touch with over the years.

With my husband just starting his website on bits of DIY around the house, I became a bit of a website widow. Plenty of time for knitting on my own, but I thought it might be a nice idea to do a bit of a website myself, as a bit of a hobby too.`,
  },
  settings: {
    title: "Settings",
    body: "Customize sounds, theme, and account preferences.",
  },
};

function App() {
  const [page, setPage] = useState("home");
  const [activeTab, setActiveTab] = useState("pattern");
  const [theme, setTheme] = useState("light");
  const [accent, setAccent] = useState("warm");
  const [clickSound, setClickSound] = useState(true);
  const [isSignedIn, setIsSignedIn] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [contactError, setContactError] = useState("");
  const [contactSuccess, setContactSuccess] = useState("");
  const [profile, setProfile] = useState({
    displayName: "",
    realName: "",
    email: "",
    bio: "",
    memberSince: "",
    patternsCompleted: "0",
  });
  const [profileSaved, setProfileSaved] = useState(false);
  const [signInError, setSignInError] = useState("");
  const [shopSearch, setShopSearch] = useState("");
  const [shopCategory, setShopCategory] = useState("All");
  const [basketCount, setBasketCount] = useState(0);
  const [basket, setBasket] = useState([]);
  const [favourites, setFavourites] = useState([]);
  const [favouritesSearch, setFavouritesSearch] = useState("");
  const [favouritesSort, setFavouritesSort] = useState("recent");
  const [patternSearch, setPatternSearch] = useState("");
  const [patternDifficulty, setPatternDifficulty] = useState("All");
  const [patternCategory, setPatternCategory] = useState("All");
  const [patternYarnWeight, setPatternYarnWeight] = useState("All");
  const [patternNeedleSize, setPatternNeedleSize] = useState("All");
  const [patternPrice, setPatternPrice] = useState("All");
  const [patternSort, setPatternSort] = useState("popular");
  const [showFilters, setShowFilters] = useState(true);
  const audioContextRef = useRef(null);
  const clickAudioRef = useRef(null);

  const shopCategories = ["All", "Yarn", "Knitting Needles", "Crochet Hooks", "Patterns", "Accessories", "Kits"];
  const shopProducts = [
    {
      id: 1,
      name: "Cloud Merino Yarn",
      price: 14.5,
      category: "Yarn",
      rating: 5,
      stock: "In stock",
      image: createPlaceholderImage("Cloud Merino Yarn", "#c98f74"),
    },
    {
      id: 2,
      name: "Oakwood Needle Set",
      price: 26,
      category: "Knitting Needles",
      rating: 4,
      stock: "Low stock",
      image: createPlaceholderImage("Oakwood Needles", "#8fa7c8"),
    },
    {
      id: 3,
      name: "Rosewood Hook Trio",
      price: 18,
      category: "Crochet Hooks",
      rating: 5,
      stock: "In stock",
      image: createPlaceholderImage("Rosewood Hooks", "#d991a8"),
    },
    {
      id: 4,
      name: "Studio Sweater Pattern",
      price: 9.5,
      category: "Patterns",
      rating: 4,
      stock: "In stock",
      image: createPlaceholderImage("Sweater Pattern", "#7f8ea8"),
    },
    {
      id: 5,
      name: "Keep Cup Needle Case",
      price: 12,
      category: "Accessories",
      rating: 4,
      stock: "In stock",
      image: createPlaceholderImage("Needle Case", "#b28d6c"),
    },
    {
      id: 6,
      name: "Weekend Knit Kit",
      price: 34,
      category: "Kits",
      rating: 5,
      stock: "In stock",
      image: createPlaceholderImage("Weekend Knit Kit", "#b07f89"),
    },
  ];

  const patternData = [
    {
      id: 101,
      kind: "pattern",
      title: "Mossberry Wrap",
      designer: "Ava Lane",
      difficulty: "Intermediate",
      estimatedTime: "6 hrs",
      yarnWeight: "DK",
      needleSize: "4 mm",
      category: "Accessories",
      price: "Free",
      rating: 4.8,
      popularity: 92,
      addedAt: "2024-07-03",
      description: "A soft wrap with gentle texture and a cosy drape.",
      image: createPlaceholderImage("Mossberry Wrap", "#c98f74"),
    },
    {
      id: 102,
      kind: "pattern",
      title: "Little Meadow Hat",
      designer: "Nora Bell",
      difficulty: "Beginner",
      estimatedTime: "2 hrs",
      yarnWeight: "Worsted",
      needleSize: "5 mm",
      category: "Clothing",
      price: "Paid",
      rating: 4.6,
      popularity: 88,
      addedAt: "2024-06-11",
      description: "A quick, cheerful hat with easy ribbing and charm.",
      image: createPlaceholderImage("Little Meadow Hat", "#8fa7c8"),
    },
    {
      id: 103,
      kind: "pattern",
      title: "Dusk Mittens",
      designer: "Mina Wren",
      difficulty: "Advanced",
      estimatedTime: "4 hrs",
      yarnWeight: "Sport",
      needleSize: "3.25 mm",
      category: "Accessories",
      price: "Paid",
      rating: 4.9,
      popularity: 95,
      addedAt: "2024-05-22",
      description: "Warm mittens with a classic thumb gusset and tidy finish.",
      image: createPlaceholderImage("Dusk Mittens", "#d991a8"),
    },
    {
      id: 104,
      kind: "pattern",
      title: "Cedar Blanket",
      designer: "Sage Hart",
      difficulty: "Intermediate",
      estimatedTime: "10 hrs",
      yarnWeight: "Bulky",
      needleSize: "6 mm",
      category: "Blankets",
      price: "Free",
      rating: 4.7,
      popularity: 90,
      addedAt: "2024-04-08",
      description: "A snuggly blanket with clear texture and a relaxed rhythm.",
      image: createPlaceholderImage("Cedar Blanket", "#7f8ea8"),
    },
    {
      id: 105,
      kind: "pattern",
      title: "Poppy Toy Rabbit",
      designer: "Clare Rowe",
      difficulty: "Beginner",
      estimatedTime: "3 hrs",
      yarnWeight: "Sport",
      needleSize: "3.5 mm",
      category: "Toys",
      price: "Paid",
      rating: 4.5,
      popularity: 84,
      addedAt: "2024-03-16",
      description: "A sweet plush rabbit with simple shaping and lots of charm.",
      image: createPlaceholderImage("Poppy Toy Rabbit", "#b07f89"),
    },
    {
      id: 106,
      kind: "pattern",
      title: "Linen Home Cushion",
      designer: "Etta Vale",
      difficulty: "Advanced",
      estimatedTime: "5 hrs",
      yarnWeight: "Cotton",
      needleSize: "4.5 mm",
      category: "Home Décor",
      price: "Paid",
      rating: 4.8,
      popularity: 91,
      addedAt: "2024-02-21",
      description: "A sculptural cushion with crisp lines and a polished finish.",
      image: createPlaceholderImage("Linen Home Cushion", "#b28d6c"),
    },
  ];

  const createAudioContext = () => {
    const AudioCtor = window.AudioContext || window.webkitAudioContext;

    if (!AudioCtor || typeof AudioCtor !== "function") {
      return null;
    }

    if (!audioContextRef.current) {
      audioContextRef.current = new AudioCtor();
    }

    if (audioContextRef.current?.state === "suspended") {
      audioContextRef.current.resume();
    }

    return audioContextRef.current;
  };

  const playHoverSound = () => {
    const ctx = createAudioContext();

    if (!ctx) {
      return;
    }

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = "triangle";
    osc.frequency.value = 720;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.03, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0008, now + 0.1);

    filter.type = "lowpass";
    filter.frequency.setValueAtTime(1800, now);
    filter.Q.setValueAtTime(4, now);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.1);
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      clickAudioRef.current = new Audio(clickMp3);
      clickAudioRef.current.preload = "auto";

      const storedBasket = window.localStorage.getItem("knitting-basket");
      if (storedBasket) {
        try {
          const parsedBasket = JSON.parse(storedBasket);
          setBasket(parsedBasket);
          setBasketCount(parsedBasket.reduce((total, item) => total + item.quantity, 0));
        } catch {
          window.localStorage.removeItem("knitting-basket");
        }
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("knitting-basket", JSON.stringify(basket));
    }
  }, [basket]);

  const playClickSound = () => {
    if (!clickSound) {
      return;
    }

    if (clickAudioRef.current) {
      clickAudioRef.current.currentTime = 0;
      try {
        clickAudioRef.current.play().catch(() => {});
      } catch {
        // Ignore audio playback issues in environments without full media support.
      }
      return;
    }

    const ctx = createAudioContext();

    if (!ctx) {
      return;
    }

    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc1.type = "triangle";
    osc1.frequency.setValueAtTime(320, now);
    osc2.type = "sine";
    osc2.frequency.setValueAtTime(200, now);

    filter.type = "lowpass";
    filter.frequency.setValueAtTime(1800, now);
    filter.frequency.exponentialRampToValueAtTime(1200, now + 0.14);
    filter.Q.setValueAtTime(5, now);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.18);
    osc2.stop(now + 0.18);
  };

  const handleHover = () => {};

  const handleClick = () => {
    if (clickSound) {
      playClickSound();
    }
  };

  const handleTab = (tab) => {
    handleClick();
    setActiveTab(tab);
  };

  const handleContactFieldChange = (field, value) => {
    setContactForm((current) => ({ ...current, [field]: value }));
    if (contactError) {
      setContactError("");
    }
    if (contactSuccess) {
      setContactSuccess("");
    }
  };

  const handleContactSubmit = (event) => {
    event.preventDefault();
    handleClick();

    const missingFields = Object.values(contactForm).some((value) => value.trim() === "");
    const isMessageLongEnough = contactForm.message.trim().length >= 150;

    if (missingFields) {
      setContactError("Please fill in all fields before sending your message.");
      setContactSuccess("");
      return;
    }

    if (!isMessageLongEnough) {
      setContactError("Please write at least 150 characters so we can help you properly.");
      setContactSuccess("");
      return;
    }

    setContactError("");
    setContactSuccess("Thanks for reaching out. We’ll get back to you soon.");
    setContactForm({ name: "", email: "", subject: "", message: "" });
  };

  const handleProfileFieldChange = (field, value) => {
    if (signInError) {
      setSignInError("");
    }

    if (field === "bio") {
      const trimmedValue = value.slice(0, 1000);
      setProfile((current) => ({ ...current, bio: trimmedValue }));
      return;
    }

    if (field === "realName") {
      const sanitizedValue = value.replace(/\d/g, "");
      setProfile((current) => ({ ...current, realName: sanitizedValue }));
      return;
    }

    if (field === "email") {
      setProfile((current) => ({ ...current, email: value }));
      return;
    }

    if (field === "memberSince") {
      const match = value.trim().match(/^([A-Za-z]+)\s(\d{4})$/);
      const normalizedValue = match ? `${match[1]} ${match[2]}` : value;
      setProfile((current) => ({ ...current, memberSince: normalizedValue }));
      return;
    }

    if (field === "patternsCompleted") {
      const digits = value.replace(/\D/g, "");
      const numericValue = digits ? Number(digits) : 0;
      const normalizedValue = numericValue > 999 ? "999" : String(numericValue).padStart(1, "0");
      setProfile((current) => ({ ...current, patternsCompleted: normalizedValue }));
      return;
    }

    setProfile((current) => ({ ...current, [field]: value }));
  };

  const isEmailValid = /.+@.+\..+/.test(profile.email.trim());
  const isMemberSinceValid = /^([A-Za-z]+)\s(\d{4})$/.test(profile.memberSince.trim());
  const isPatternsValid = /^\d{1,3}$/.test(profile.patternsCompleted.trim());
  const isRealNameValid = /^[A-Za-z\s]+$/.test(profile.realName.trim());
  const isBioValid = profile.bio.trim().length >= 1 && profile.bio.trim().length <= 1000;
  const isContactNameValid = contactForm.name.trim().length > 0;
  const isContactEmailValid = /.+@.+\..+/.test(contactForm.email.trim());
  const isContactSubjectValid = contactForm.subject.trim().length > 0;
  const isContactMessageValid = contactForm.message.trim().length >= 150;

  const isProfileComplete = [
    profile.displayName,
    profile.realName,
    profile.email,
    profile.bio,
    profile.memberSince,
    profile.patternsCompleted,
  ].every((value) => String(value).trim() !== "");

  const isProfileValid = isProfileComplete && isEmailValid && isMemberSinceValid && isPatternsValid && isRealNameValid && isBioValid;

  const handleSignIn = () => {
    handleClick();

    if (!isProfileValid) {
      setSignInError("Please enter a valid real name, email, member since date, and patterns count before signing in.");
      return;
    }

    setSignInError("");
    setIsSignedIn(true);
    setProfileSaved(false);
  };

  const handleSignOut = () => {
    handleClick();
    setIsSignedIn(false);
    setProfileSaved(false);
  };

  const handleProfileSave = () => {
    handleClick();
    setProfileSaved(true);
  };

  const avatarLabel = isSignedIn && profile.realName.trim()
    ? profile.realName.trim().split(/\s+/)[0].slice(0, 1).toUpperCase()
    : "";

  const filteredShopProducts = shopProducts.filter((product) => {
    const matchesCategory = shopCategory === "All" || product.category === shopCategory;
    const query = shopSearch.toLowerCase();
    const matchesSearch =
      product.name.toLowerCase().includes(query) ||
      product.category.toLowerCase().includes(query);

    return matchesCategory && matchesSearch;
  });

  const filteredPatterns = patternData
    .filter((pattern) => {
      const query = patternSearch.toLowerCase();
      const matchesSearch =
        pattern.title.toLowerCase().includes(query) ||
        pattern.designer.toLowerCase().includes(query) ||
        pattern.description.toLowerCase().includes(query);
      const matchesDifficulty = patternDifficulty === "All" || pattern.difficulty === patternDifficulty;
      const matchesCategory = patternCategory === "All" || pattern.category === patternCategory;
      const matchesYarnWeight = patternYarnWeight === "All" || pattern.yarnWeight === patternYarnWeight;
      const matchesNeedleSize = patternNeedleSize === "All" || pattern.needleSize === patternNeedleSize;
      const matchesPrice = patternPrice === "All" || pattern.price === patternPrice;

      return matchesSearch && matchesDifficulty && matchesCategory && matchesYarnWeight && matchesNeedleSize && matchesPrice;
    })
    .sort((left, right) => {
      if (patternSort === "az") {
        return left.title.localeCompare(right.title);
      }

      if (patternSort === "newest") {
        return new Date(right.addedAt) - new Date(left.addedAt);
      }

      if (patternSort === "rating") {
        return right.rating - left.rating;
      }

      return right.popularity - left.popularity;
    });

  const patternDifficultyOptions = ["All", "Beginner", "Intermediate", "Advanced"];
  const patternCategoryOptions = ["All", "Accessories", "Clothing", "Blankets", "Toys", "Home Décor"];
  const patternYarnWeightOptions = ["All", "DK", "Worsted", "Sport", "Bulky", "Cotton"];
  const patternNeedleSizeOptions = ["All", "3.25 mm", "3.5 mm", "4 mm", "4.5 mm", "5 mm", "6 mm"];
  const patternPriceOptions = ["All", "Free", "Paid"];

  const handleAddToBasket = (product) => {
    handleClick();
    setBasket((current) => {
      const existingItem = current.find((item) => item.id === product.id);
      if (existingItem) {
        return current.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
      }

      return [
        ...current,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          category: product.category,
          stock: product.stock,
          quantity: 1,
        },
      ];
    });
    setBasketCount((current) => current + 1);
  };

  const handleBasketQuantityChange = (productId, delta) => {
    handleClick();
    const targetItem = basket.find((item) => item.id === productId);
    if (!targetItem && delta > 0) {
      return;
    }

    setBasket((current) =>
      current.flatMap((item) => {
        if (item.id !== productId) {
          return [item];
        }

        const nextQuantity = item.quantity + delta;
        return nextQuantity > 0 ? [{ ...item, quantity: nextQuantity }] : [];
      })
    );

    setBasketCount((current) => Math.max(0, current + delta));
  };

  const handleRemoveBasketItem = (productId) => {
    handleClick();
    const targetItem = basket.find((item) => item.id === productId);
    if (!targetItem) {
      return;
    }

    setBasket((current) => current.filter((item) => item.id !== productId));
    setBasketCount((current) => Math.max(0, current - targetItem.quantity));
  };

  const handleToggleFavourite = (item) => {
    handleClick();
    setFavourites((current) => {
      const id = typeof item === "object" ? item.id : item;

      if (current.some((existing) => existing.id === id)) {
        return current.filter((existing) => existing.id !== id);
      }

      const product = shopProducts.find((entry) => entry.id === id);
      const pattern = patternData.find((entry) => entry.id === id);

      const favouriteItem = product
        ? {
            id: product.id,
            name: product.name,
            difficulty: "Varied",
            yarnWeight: "Mixed",
            description: `${product.category} pick for your next cosy project.`,
            image: product.image,
            addedAt: new Date().toISOString(),
          }
        : pattern
          ? {
              id: pattern.id,
              name: pattern.title,
              difficulty: pattern.difficulty,
              yarnWeight: pattern.yarnWeight,
              description: pattern.description,
              image: pattern.image,
              addedAt: new Date().toISOString(),
            }
          : null;

      if (!favouriteItem) {
        return current;
      }

      return [favouriteItem, ...current];
    });
  };

  const filteredFavourites = favourites
    .filter((pattern) => {
      const query = favouritesSearch.toLowerCase();
      return (
        pattern.name.toLowerCase().includes(query) ||
        pattern.description.toLowerCase().includes(query) ||
        pattern.difficulty.toLowerCase().includes(query)
      );
    })
    .sort((left, right) => {
      if (favouritesSort === "az") {
        return left.name.localeCompare(right.name);
      }

      if (favouritesSort === "difficulty") {
        return left.difficulty.localeCompare(right.difficulty);
      }

      return new Date(right.addedAt) - new Date(left.addedAt);
    });

  const wrapperClass = `app theme-${theme} accent-${accent}`;

  return (
    <div className={wrapperClass}>
      {page === "home" ? (
        <div className="home">
          <div className="home__overlay">
            <div className="home__badges">
              <span className="home__pill">Cosy patterns</span>
              <span className="home__pill">Handmade charm</span>
              <span className="home__pill">Warm studio</span>
            </div>
            <h1 className="home__title">
              <span className="home__flower">❀</span>
              My Knitting App
              <span className="home__flower">❀</span>
            </h1>
            <p className="home__subtitle">Welcome to your knitting space. Explore patterns, favourites, and more with a warm, woven feel.</p>
            <div className="home__cta-row">
              <button
                className="home__continue"
                onClick={() => {
                  handleClick();
                  setPage("dashboard");
                }}
              >
                Continue
              </button>
              <span className="home__support">A little place for your next lovely knit.</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="dashboard">
          <aside className="dashboard__sidebar">
            <button
              className={activeTab === "pattern" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("pattern")}
            >
              Pattern Dashboard
            </button>
            <button
              className={activeTab === "favourites" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("favourites")}
            >
              Favourites
            </button>
            <button
              className={activeTab === "account" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("account")}
            >
              My Account
            </button>
            <button
              className={activeTab === "shop" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("shop")}
            >
              Shop
            </button>
            <button
              className={activeTab === "basket" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("basket")}
            >
              Basket
            </button>
            <button
              className={activeTab === "contact" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("contact")}
            >
              Contact Us
            </button>
            <button
              className={activeTab === "about" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("about")}
            >
              About
            </button>
            <button
              className={activeTab === "settings" ? "dashboard__tab dashboard__tab--active" : "dashboard__tab"}
              onMouseEnter={handleHover}
              onClick={() => handleTab("settings")}
            >
              Settings
            </button>
          </aside>
          <main className="dashboard__content">
            <div key={activeTab} className="dashboard__panel dashboard__panel--wide">
              {activeTab === "settings" ? (
                <div className="settings-page">
                  <h1>{tabContent.settings.title}</h1>
                  <div className="settings-card">
                    <h2>Sound settings</h2>
                    <label className="settings-toggle">
                      <span>Click sound</span>
                      <input
                        type="checkbox"
                        checked={clickSound}
                        onChange={() => {
                          handleClick();
                          setClickSound((current) => !current);
                        }}
                      />
                    </label>
                  </div>
                  <div className="settings-card">
                    <h2>Theme settings</h2>
                    <div className="settings-field">
                      <span>Mode</span>
                      <div className="settings-options">
                        <button
                          className={theme === "light" ? "settings-option settings-option--active" : "settings-option"}
                          onMouseEnter={handleHover}
                          onClick={() => {
                            handleClick();
                            setTheme("light");
                          }}
                        >
                          Light
                        </button>
                        <button
                          className={theme === "dark" ? "settings-option settings-option--active" : "settings-option"}
                          onMouseEnter={handleHover}
                          onClick={() => {
                            handleClick();
                            setTheme("dark");
                          }}
                        >
                          Dark
                        </button>
                      </div>
                    </div>
                    <div className="settings-field">
                      <span>Accent</span>
                      <div className="settings-options">
                        <button
                          className={accent === "warm" ? "settings-option settings-option--active" : "settings-option"}
                          onMouseEnter={handleHover}
                          onClick={() => {
                            handleClick();
                            setAccent("warm");
                          }}
                        >
                          Warm
                        </button>
                        <button
                          className={accent === "cool" ? "settings-option settings-option--active" : "settings-option"}
                          onMouseEnter={handleHover}
                          onClick={() => {
                            handleClick();
                            setAccent("cool");
                          }}
                        >
                          Cool
                        </button>
                        <button
                          className={accent === "blush" ? "settings-option settings-option--active" : "settings-option"}
                          onMouseEnter={handleHover}
                          onClick={() => {
                            handleClick();
                            setAccent("blush");
                          }}
                        >
                          Blush
                        </button>
                      </div>
                    </div>
                  </div>
                  {isSignedIn ? (
                    <div className="settings-card settings-card--danger">
                      <h2>Account actions</h2>
                      <p>This is a placeholder for signing out of your knitting workspace.</p>
                      <button
                        className="button button--danger"
                        onMouseEnter={handleHover}
                        onClick={() => {
                          handleClick();
                          handleSignOut();
                        }}
                      >
                        Sign out
                      </button>
                    </div>
                  ) : null}
                </div>
              ) : activeTab === "contact" ? (
                <div className="contact-page">
                  <h1>{tabContent.contact.title}</h1>
                  <p className="contact-page__subtitle">Send us a warm message and we’ll get back to you soon.</p>
                  <div className="contact-details">
                    <div className="contact-details__card">
                      <h2>OFFICIAL CONTACT INFORMATION</h2>
                      <dl>
                        <dt>Trade name</dt>
                        <dd>Fitting in Knitting</dd>
                        <dt>Email</dt>
                        <dd>ali@fittinginknitting.co.uk</dd>
                        <dt>Physical address</dt>
                        <dd>113 Scalford Road, LE13 1JZ, United Kingdom</dd>
                        <dt>VAT number</dt>
                        <dd>N/A</dd>
                        <dt>Company Name</dt>
                        <dd>Ali And Chap LTD</dd>
                        <dt>Trade Company number</dt>
                        <dd>11611069</dd>
                        <dt>Phone number</dt>
                        <dd>00447870542074</dd>
                      </dl>
                    </div>
                    <form className="contact-form" onSubmit={handleContactSubmit}>
                      <div className="contact-row">
                        <label className="input-field">
                          <span>Name</span>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                            <input
                              type="text"
                              value={contactForm.name}
                              onChange={(event) => handleContactFieldChange("name", event.target.value)}
                              placeholder="Your full name"
                            />
                            <span className={`validation-indicator ${isContactNameValid ? "" : "validation-indicator--invalid"}`}>{isContactNameValid ? "✓" : "•"}</span>
                          </div>
                        </label>
                        <label className="input-field">
                          <span>Email</span>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                            <input
                              type="email"
                              value={contactForm.email}
                              onChange={(event) => handleContactFieldChange("email", event.target.value)}
                              placeholder="you@example.com"
                            />
                            <span className={`validation-indicator ${isContactEmailValid ? "" : "validation-indicator--invalid"}`}>{isContactEmailValid ? "✓" : "•"}</span>
                          </div>
                        </label>
                      </div>
                      <label className="input-field">
                        <span>Subject</span>
                        <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                          <input
                            type="text"
                            value={contactForm.subject}
                            onChange={(event) => handleContactFieldChange("subject", event.target.value)}
                            placeholder="Topic of your message"
                          />
                          <span className={`validation-indicator ${isContactSubjectValid ? "" : "validation-indicator--invalid"}`}>{isContactSubjectValid ? "✓" : "•"}</span>
                        </div>
                      </label>
                      <label className="input-field">
                        <span>Message</span>
                        <textarea
                          value={contactForm.message}
                          onChange={(event) => handleContactFieldChange("message", event.target.value)}
                          placeholder="Tell us what you'd like to share..."
                          rows={8}
                        />
                        <span className={`counter-pill ${contactForm.message.trim().length < 150 ? "counter-pill--warning" : ""}`}>
                          {contactForm.message.trim().length}/150
                        </span>
                      </label>
                      {contactError ? <p className="account-feedback account-feedback--error">{contactError}</p> : null}
                      {contactSuccess ? <p className="account-feedback">{contactSuccess}</p> : null}
                      <button className="button button--primary" onMouseEnter={handleHover} type="submit">
                        Send Message
                      </button>
                    </form>
                  </div>
                </div>
              ) : activeTab === "account" ? (
                <div className="account-page">
                  <div className="account-hero">
                    <div className={`account-avatar ${isSignedIn ? "account-avatar--filled" : ""}`}>{avatarLabel}</div>
                    <div>
                      <h1>{tabContent.account.title}</h1>
                      <p className="about-page__subtitle">Keep your knitting workspace warm, personal, and beautifully organised.</p>
                    </div>
                  </div>
                  <div className="account-grid">
                    <div className="settings-card">
                      <h2>Profile details</h2>
                      <div className="account-form">
                        <label className="input-field">
                          <span>Display name</span>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                            <input
                              type="text"
                              value={profile.displayName}
                              onChange={(event) => handleProfileFieldChange("displayName", event.target.value)}
                              placeholder="Display name"
                            />
                            <span className={`validation-indicator ${profile.displayName.trim() ? "" : "validation-indicator--invalid"}`}>{profile.displayName.trim() ? "✓" : "•"}</span>
                          </div>
                        </label>
                        <label className="input-field">
                          <span>Real name</span>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                            <input
                              type="text"
                              value={profile.realName}
                              onChange={(event) => handleProfileFieldChange("realName", event.target.value)}
                              placeholder="Real name"
                            />
                            <span className={`validation-indicator ${isRealNameValid && profile.realName.trim() ? "" : "validation-indicator--invalid"}`}>{isRealNameValid && profile.realName.trim() ? "✓" : "•"}</span>
                          </div>
                        </label>
                        <label className="input-field">
                          <span>Email</span>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                            <input
                              type="email"
                              value={profile.email}
                              onChange={(event) => handleProfileFieldChange("email", event.target.value)}
                              placeholder="Email"
                            />
                            <span className={`validation-indicator ${isEmailValid && profile.email.trim() ? "" : "validation-indicator--invalid"}`}>{isEmailValid && profile.email.trim() ? "✓" : "•"}</span>
                          </div>
                        </label>
                        <label className="input-field">
                          <span>Member since</span>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                            <input
                              type="text"
                              value={profile.memberSince}
                              onChange={(event) => handleProfileFieldChange("memberSince", event.target.value)}
                              placeholder="e.g. April 2024"
                            />
                            <span className={`validation-indicator ${isMemberSinceValid && profile.memberSince.trim() ? "" : "validation-indicator--invalid"}`}>{isMemberSinceValid && profile.memberSince.trim() ? "✓" : "•"}</span>
                          </div>
                        </label>
                        <label className="input-field">
                          <span>Patterns completed</span>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                            <input
                              type="text"
                              inputMode="numeric"
                              value={profile.patternsCompleted}
                              onChange={(event) => handleProfileFieldChange("patternsCompleted", event.target.value)}
                              placeholder="0"
                            />
                            <span className={`validation-indicator ${isPatternsValid && profile.patternsCompleted.trim() ? "" : "validation-indicator--invalid"}`}>{isPatternsValid && profile.patternsCompleted.trim() ? "✓" : "•"}</span>
                          </div>
                        </label>
                        <label className="input-field">
                          <span>Short bio</span>
                          <textarea
                            value={profile.bio}
                            onChange={(event) => handleProfileFieldChange("bio", event.target.value)}
                            rows={4}
                            placeholder="Tell us a little about your knitting"
                          />
                          <span className={`counter-pill ${profile.bio.trim().length < 1 || profile.bio.trim().length > 1000 ? "counter-pill--warning" : ""}`}>
                            {profile.bio.trim().length}/1000
                          </span>
                        </label>
                      </div>
                      <div className="account-actions-row">
                        {isSignedIn ? (
                          <button
                            className="button button--primary"
                            onMouseEnter={handleHover}
                            onClick={handleProfileSave}
                            type="button"
                          >
                            Save changes
                          </button>
                        ) : null}
                        <button
                          className="button button--secondary"
                          onMouseEnter={handleHover}
                          onClick={handleSignIn}
                          type="button"
                          disabled={!isProfileComplete}
                        >
                          {isSignedIn ? "Signed in" : "Sign in"}
                        </button>
                      </div>
                      {signInError ? <p className="account-feedback account-feedback--error">{signInError}</p> : null}
                      {profileSaved ? <p className="account-feedback">Your profile is looking lovely and up to date.</p> : null}
                    </div>
                    <div className="account-stack">
                      {isSignedIn ? (
                        <>
                          <div className="settings-card account-panel account-panel--enter">
                            <h2>Member snapshot</h2>
                            <div className="account-stat">
                              <span>Member since</span>
                              <strong>{profile.memberSince || "Add a start date"}</strong>
                            </div>
                            <div className="account-stat">
                              <span>Patterns completed</span>
                              <strong>{profile.patternsCompleted || "Add a count"}</strong>
                            </div>
                          </div>
                          <div className="settings-card settings-card--danger account-panel account-panel--enter">
                            <h2>Account actions</h2>
                            <p>Sign out when you’re stepping away from your knitting nook.</p>
                            <button
                              className="button button--danger"
                              onMouseEnter={handleHover}
                              onClick={handleSignOut}
                              type="button"
                            >
                              Sign out
                            </button>
                          </div>
                        </>
                      ) : null}
                    </div>
                  </div>
                </div>
              ) : activeTab === "pattern" ? (
                <div className="pattern-page">
                  <div className="pattern__hero">
                    <div>
                      <h1>{tabContent.pattern.title}</h1>
                      <p className="shop__subtitle">Discover inspiring projects, compare silhouettes, and find your next favourite knit.</p>
                    </div>
                    <div className="pattern__hero-badge">{filteredPatterns.length} patterns ready</div>
                  </div>
                  <div className="pattern__toolbar">
                    <label className="shop__search pattern__search">
                      <span className="shop__search-icon">🔎</span>
                      <input
                        type="text"
                        value={patternSearch}
                        onChange={(event) => setPatternSearch(event.target.value)}
                        placeholder="Search patterns"
                      />
                    </label>
                    <button className="pattern__toggle" type="button" onMouseEnter={handleHover} onClick={() => setShowFilters((current) => !current)}>
                      {showFilters ? "Hide filter options" : "Show filter options"}
                    </button>
                    {showFilters ? (
                      <>
                        <div className="pattern__selects">
                          <label className="pattern__field">
                            <span>Difficulty</span>
                            <select value={patternDifficulty} onChange={(event) => setPatternDifficulty(event.target.value)}>
                              {patternDifficultyOptions.map((option) => (
                                <option key={option} value={option}>
                                  {option}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label className="pattern__field">
                            <span>Category</span>
                            <select value={patternCategory} onChange={(event) => setPatternCategory(event.target.value)}>
                              {patternCategoryOptions.map((option) => (
                                <option key={option} value={option}>
                                  {option}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label className="pattern__field">
                            <span>Yarn</span>
                            <select value={patternYarnWeight} onChange={(event) => setPatternYarnWeight(event.target.value)}>
                              {patternYarnWeightOptions.map((option) => (
                                <option key={option} value={option}>
                                  {option}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label className="pattern__field">
                            <span>Needles</span>
                            <select value={patternNeedleSize} onChange={(event) => setPatternNeedleSize(event.target.value)}>
                              {patternNeedleSizeOptions.map((option) => (
                                <option key={option} value={option}>
                                  {option}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label className="pattern__field">
                            <span>Price</span>
                            <select value={patternPrice} onChange={(event) => setPatternPrice(event.target.value)}>
                              {patternPriceOptions.map((option) => (
                                <option key={option} value={option}>
                                  {option}
                                </option>
                              ))}
                            </select>
                          </label>
                        </div>
                      </>
                    ) : null}
                    <div className="pattern__sorts">
                      <button className={patternSort === "popular" ? "shop__filter shop__filter--active" : "shop__filter"} type="button" onMouseEnter={handleHover} onClick={() => setPatternSort("popular")}>Most Popular</button>
                      <button className={patternSort === "az" ? "shop__filter shop__filter--active" : "shop__filter"} type="button" onMouseEnter={handleHover} onClick={() => setPatternSort("az")}>A–Z</button>
                      <button className={patternSort === "newest" ? "shop__filter shop__filter--active" : "shop__filter"} type="button" onMouseEnter={handleHover} onClick={() => setPatternSort("newest")}>Newest</button>
                      <button className={patternSort === "rating" ? "shop__filter shop__filter--active" : "shop__filter"} type="button" onMouseEnter={handleHover} onClick={() => setPatternSort("rating")}>Highest Rated</button>
                    </div>
                  </div>
                  <div className="pattern__grid">
                    {filteredPatterns.map((pattern) => {
                      const isFavourite = favourites.some((item) => item.id === pattern.id);

                      return (
                        <article className="pattern-card" key={pattern.id}>
                          <img className="pattern-card__image" src={pattern.image} alt={pattern.title} />
                          <div className="pattern-card__body">
                            <div className="pattern-card__top">
                              <div>
                                <p className="pattern-card__designer">{pattern.designer}</p>
                                <h3>{pattern.title}</h3>
                              </div>
                              <button
                                className={`shop-card__heart ${isFavourite ? "shop-card__heart--active" : ""}`}
                                type="button"
                                onMouseEnter={handleHover}
                                onClick={() => handleToggleFavourite(pattern)}
                                aria-label={isFavourite ? `Remove ${pattern.title} from favourites` : `Favourite ${pattern.title}`}
                              >
                                ♥
                              </button>
                            </div>
                            <p className="pattern-card__description">{pattern.description}</p>
                            <div className="pattern-card__meta">
                              <span>{pattern.difficulty}</span>
                              <span>{pattern.estimatedTime}</span>
                              <span>{pattern.yarnWeight}</span>
                              <span>{pattern.needleSize}</span>
                            </div>
                            <div className="pattern-card__footer">
                              <div>
                                <div className="shop-card__rating">{'★'.repeat(Math.round(pattern.rating))}{'☆'.repeat(5 - Math.round(pattern.rating))}</div>
                                <span className="pattern-card__price">{pattern.price}</span>
                              </div>
                              <div className="pattern-card__actions">
                                <button className="shop-card__button shop-card__button--ghost" type="button" onMouseEnter={handleHover}>View Pattern</button>
                                <button className="shop-card__button" type="button" onMouseEnter={handleHover} onClick={() => handleToggleFavourite(pattern)}>Add to Favourites</button>
                              </div>
                            </div>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </div>
              ) : activeTab === "shop" ? (
                <div className="shop-page">
                  <div className="shop__header">
                    <div>
                      <h1>{tabContent.shop.title}</h1>
                      <p className="shop__subtitle">Browse cosy essentials, delightful tools, and fresh patterns.</p>
                    </div>
                    <button className="shop__basket" aria-label={`View basket with ${basketCount} items`} type="button" onMouseEnter={handleHover} onClick={() => { handleClick(); setActiveTab("basket"); }}>
                      <span className="shop__basket-icon">🛍️</span>
                      <span className="shop__basket-count">{basketCount}</span>
                    </button>
                  </div>
                  <div className="shop__toolbar">
                    <label className="shop__search">
                      <span className="shop__search-icon">🔎</span>
                      <input
                        type="text"
                        value={shopSearch}
                        onChange={(event) => setShopSearch(event.target.value)}
                        placeholder="Search products"
                      />
                    </label>
                    <div className="shop__filters">
                      {shopCategories.map((category) => (
                        <button
                          key={category}
                          className={shopCategory === category ? "shop__filter shop__filter--active" : "shop__filter"}
                          onMouseEnter={handleHover}
                          onClick={() => setShopCategory(category)}
                          type="button"
                        >
                          {category}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="shop__grid">
                    {filteredShopProducts.map((product) => {
                      const isFavourite = favourites.some((item) => item.id === product.id);

                      return (
                        <article className="shop-card" key={product.id}>
                          <div className="shop-card__image-wrap">
                            <img className="shop-card__image" src={product.image} alt={product.name} />
                            <button
                              className={`shop-card__heart ${isFavourite ? "shop-card__heart--active" : ""}`}
                              type="button"
                              onMouseEnter={handleHover}
                              onClick={() => handleToggleFavourite(product)}
                              aria-label={isFavourite ? `Remove ${product.name} from favourites` : `Favourite ${product.name}`}
                            >
                              ♥
                            </button>
                          </div>
                          <div className="shop-card__body">
                            <div className="shop-card__meta">
                              <span className="shop-card__category">{product.category}</span>
                              <span className="shop-card__stock">{product.stock}</span>
                            </div>
                            <h3>{product.name}</h3>
                            <div className="shop-card__rating">{'★'.repeat(product.rating)}{'☆'.repeat(5 - product.rating)}</div>
                            <div className="shop-card__footer">
                              <span className="shop-card__price">£{product.price.toFixed(2)}</span>
                              <div className="shop-card__actions">
                                <button className="shop-card__button shop-card__button--ghost" type="button" onMouseEnter={handleHover}>
                                  View Details
                                </button>
                                <button className="shop-card__button" type="button" onMouseEnter={handleHover} onClick={() => handleAddToBasket(product)}>
                                  Add to Basket
                                </button>
                              </div>
                            </div>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </div>
              ) : activeTab === "basket" ? (
                <div className="basket-page">
                  <div className="basket__header">
                    <div>
                      <h1>Your Basket</h1>
                      <p className="shop__subtitle">{basketCount} item{basketCount === 1 ? "" : "s"} ready for your next cosy project.</p>
                    </div>
                    <button className="button button--secondary" type="button" onMouseEnter={handleHover} onClick={() => { handleClick(); setActiveTab("shop"); }}>
                      Continue Shopping
                    </button>
                  </div>
                  {basket.length === 0 ? (
                    <div className="basket__empty">
                      <div className="basket__empty-illustration">🧺</div>
                      <h2>Your basket is empty</h2>
                      <p>Bring a little warmth home by adding a few favourites from the shop.</p>
                      <button className="button button--primary" type="button" onMouseEnter={handleHover} onClick={() => { handleClick(); setActiveTab("shop"); }}>
                        Return to Shop
                      </button>
                    </div>
                  ) : (
                    <div className="basket__content">
                      <div className="basket__list">
                        {basket.map((item) => {
                          const subtotal = item.price * item.quantity;
                          return (
                            <article className="basket-card" key={item.id}>
                              <img className="basket-card__image" src={item.image} alt={item.name} />
                              <div className="basket-card__body">
                                <div className="basket-card__top">
                                  <div>
                                    <h3>{item.name}</h3>
                                    <p>{item.category}</p>
                                  </div>
                                  <span className="basket-card__price">£{subtotal.toFixed(2)}</span>
                                </div>
                                <div className="basket-card__controls">
                                  <div className="basket-card__quantity">
                                    <button type="button" className="basket-card__quantity-button" onMouseEnter={handleHover} onClick={() => handleBasketQuantityChange(item.id, -1)}>-</button>
                                    <span>{item.quantity}</span>
                                    <button type="button" className="basket-card__quantity-button" onMouseEnter={handleHover} onClick={() => handleBasketQuantityChange(item.id, 1)}>+</button>
                                  </div>
                                  <button className="basket-card__remove" type="button" onMouseEnter={handleHover} onClick={() => handleRemoveBasketItem(item.id)}>Remove</button>
                                </div>
                              </div>
                            </article>
                          );
                        })}
                      </div>
                      <aside className="basket__summary">
                        <h2>Order Summary</h2>
                        <div className="basket__summary-row"><span>Subtotal</span><strong>£{basket.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2)}</strong></div>
                        <div className="basket__summary-row"><span>Estimated delivery</span><strong>£4.50</strong></div>
                        <div className="basket__summary-row"><span>Discount</span><strong>£0.00</strong></div>
                        <div className="basket__summary-row basket__summary-row--total"><span>Total</span><strong>£{(basket.reduce((sum, item) => sum + item.price * item.quantity, 0) + 4.5).toFixed(2)}</strong></div>
                        <button className="button button--primary basket__checkout" type="button" onMouseEnter={handleHover}>Proceed to Checkout</button>
                      </aside>
                    </div>
                  )}
                </div>
              ) : activeTab === "favourites" ? (
                <div className="favourites-page">
                  <div className="favourites__header">
                    <div>
                      <h1>{tabContent.favourites.title}</h1>
                      <p className="shop__subtitle">Your favourite patterns, all in one cosy collection.</p>
                    </div>
                    <div className="favourites__controls">
                      <label className="shop__search favourites__search">
                        <span className="shop__search-icon">🔎</span>
                        <input
                          type="text"
                          value={favouritesSearch}
                          onChange={(event) => setFavouritesSearch(event.target.value)}
                          placeholder="Search favourites"
                        />
                      </label>
                      <div className="favourites__sort">
                        <button
                          className={favouritesSort === "recent" ? "shop__filter shop__filter--active" : "shop__filter"}
                          type="button"
                          onMouseEnter={handleHover}
                          onClick={() => setFavouritesSort("recent")}
                        >
                          Recently Added
                        </button>
                        <button
                          className={favouritesSort === "az" ? "shop__filter shop__filter--active" : "shop__filter"}
                          type="button"
                          onMouseEnter={handleHover}
                          onClick={() => setFavouritesSort("az")}
                        >
                          A–Z
                        </button>
                        <button
                          className={favouritesSort === "difficulty" ? "shop__filter shop__filter--active" : "shop__filter"}
                          type="button"
                          onMouseEnter={handleHover}
                          onClick={() => setFavouritesSort("difficulty")}
                        >
                          Difficulty
                        </button>
                      </div>
                    </div>
                  </div>
                  {filteredFavourites.length === 0 ? (
                    <div className="favourites__empty">
                      <div className="favourites__empty-illustration">🧶</div>
                      <h2>No favourites yet</h2>
                      <p>Add a few patterns from the shop to keep your next project close at hand.</p>
                      <button className="button button--primary" type="button" onMouseEnter={handleHover} onClick={() => handleTab("shop")}>Browse Patterns</button>
                    </div>
                  ) : (
                    <div className="favourites__grid">
                      {filteredFavourites.map((pattern) => (
                        <article className="favourites-card" key={pattern.id}>
                          <img className="favourites-card__image" src={pattern.image} alt={pattern.name} />
                          <div className="favourites-card__body">
                            <div className="favourites-card__meta">
                              <span className="shop-card__category">{pattern.difficulty}</span>
                              <span className="shop-card__stock">{pattern.yarnWeight}</span>
                            </div>
                            <h3>{pattern.name}</h3>
                            <p>{pattern.description}</p>
                            <div className="favourites-card__actions">
                              <button className="shop-card__button" type="button" onMouseEnter={handleHover}>View Pattern</button>
                              <button className="shop-card__button shop-card__button--ghost" type="button" onMouseEnter={handleHover} onClick={() => handleToggleFavourite(pattern)}>
                                Remove from Favourites
                              </button>
                            </div>
                          </div>
                        </article>
                      ))}
                    </div>
                  )}
                </div>
              ) : activeTab === "about" ? (
                <div className="about-page">
                  <h1>{tabContent.about.title}</h1>
                  <p className="about-page__subtitle">A warm, spread-out story of gratitude, knitting, and making something special.</p>
                  <div className="about-page__layout">
                    <div className="about-page__text">
                      {tabContent.about.body.split("\n\n").map((paragraph, index) => (
                        <p key={index}>{paragraph}</p>
                      ))}
                    </div>
                    <div className="about-page__gallery">
                      <img
                        src={aboutDuck}
                        alt="Knitted duck and yarn"
                        className="about-page__image about-page__image--hero"
                      />
                      <div className="about-page__gallery-row">
                        <img
                          src={aboutYarnAndNeedles}
                          alt="Yarn and needles"
                          className="about-page__image"
                        />
                        <img
                          src={aboutChristian}
                          alt="Knitted pieces on display"
                          className="about-page__image"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  <h1>{tabContent[activeTab].title}</h1>
                  <p>{tabContent[activeTab].body}</p>
                </>
              )}
            </div>
          </main>
        </div>
      )}
    </div>
  );
}

export default App;